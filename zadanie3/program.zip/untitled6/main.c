#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include "program.h"

void testovanie(){
    srand(time(0));
    int var = 10;                //počet premenných, max - 13
    int variations = 10;         //počet opakovaní, max - 2000
    int size = pow(2,var);      //Dĺžka vektora
    char *vector;
    struct BDD* bdd;
    struct BF *bf;
    char **variables = createVariables(var,size);         //Vytvorenie premenných na testovanie
    int value[size];

    for(int i = 0; i<variations; i++){
        printf("TEST N.%d\n",i+1);
        vector = randomString(size);

        //VYTOVRENIE BF ŠTRUKTÚRY S VEKTOROM
        bf = (BF*) malloc(sizeof(BF));
        bf->vector = (char*) malloc(strlen(vector)*sizeof(char));
        bf->vector = vector;
        bf->length = strlen(vector);


        //ČAS
        clock_t begin = clock();

        //Vytvorenie BDD štruktúry
        bdd = BDD_create(bf);
        int before = bdd->nodeCount;
        printf("Počet uzlov po vytovrení: %d\n",before);

        //ČAS
        clock_t end = clock();
        double time_spent = (double)(end - begin) / CLOCKS_PER_SEC;



        for(int i=0; i<size; i++){
            value[i] = BDD_use(bdd,variables[i]);
        }


        //REDUCE
        BDD_reduce(bdd);
        printf("Počet uzlov po redukcii: %d\n",bdd->nodeCount);



        printf("Percento redukcie %.2f%%\n",100-(float)bdd->nodeCount/((float)before/100));
        for(int i=0; i<size; i++){
            int after = BDD_use(bdd,variables[i]);
            if(value[i]!=after){
                printf("error\n");
            }
        }


        printf("ČAS: %.3fms\n",time_spent*1000);
        printf("\n");
    }
}


int main() {
    testovanie();
    return 0;
}
