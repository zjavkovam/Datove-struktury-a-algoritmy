//
// Created by Monika Zjavková on 03/05/2021.
//

#ifndef UNTITLED6_PROGRAM_H
#define UNTITLED6_PROGRAM_H


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

typedef struct Node{
    char *value;
    int reduced;
    struct Node *left;
    struct Node *right;
    struct Node *parent;
}Node;



typedef struct BF{
    int length;
    char *vector;
}BF;

typedef struct BDD{
    int varCount;
    int nodeCount;
    struct Node *root;
}BDD;


//POMOCNÁ FUNKCIA NA VYTVORENIE NOVÉHO UZLA
struct Node* createNode(char *value, struct Node* parent){
    int size = strlen(value);
    struct Node* newNode;

    newNode = (Node*) malloc(sizeof(struct Node));
    newNode->value = (char *) malloc((size+1)*sizeof(char));
    strcpy(newNode->value,value);
    newNode->reduced = 0;
    newNode->right = NULL;
    newNode->left = NULL;
    newNode->parent = parent;

    return newNode;
}


struct Node *insert(struct Node *node, char* value){
    //Ak ešte root nebol vytvorený
    if(node == NULL){
        node = createNode(value,NULL);
    }


    //Ak je hodnota 1 alebo 0, strom sa nachádza v liste a rekurzia sa ukoncčí
    if(strlen(value)==1){
        return node;
    }

    //Rozdelenie pôvodného vektora na polovičku
    int size = strlen(value)/2;
    char left[size+1];
    char right[size+1];

    for (int i = 0; i < size; ++i) {
        left[i] = value[i];
        right[i] = value[i + size];
    }
    right[size]='\0';
    left[size]='\0';

    //Vytvorenie ľavého a pravého potomka
    node->left = createNode(left, node);
    node->right = createNode(right,node);

    //rekurzívne volanie pre ďalšíe  delenie vektora
    insert(node->left,node->left->value);
    insert(node->right,node->right->value);

    return node;
}


BDD *BDD_create(BF *bfunkcia){
    struct BDD *myBDD;
    myBDD = (BDD*) malloc(sizeof(BDD));

    //Vytvorenie stromu
    struct Node *root=NULL;
    root = insert(root,bfunkcia->vector);

    myBDD->root = root;
    myBDD->varCount = (int)log2(bfunkcia->length);       //počet premenných
    myBDD->nodeCount = (bfunkcia->length*2)-1;           //počet uzlov v strome
    return myBDD;
}


void checkSibling(struct Node *node, struct Node *sibling, BDD *bdd){
    //Ak sa ľavé strany rovnajú
    if(sibling->left!=NULL && !strcmp(node->left->value,sibling->left->value) && sibling->left!=node->left){
        sibling->left = node->left;
        sibling->reduced++;
        bdd->nodeCount--;
    }

    //ak sa rovná ľavá strana s pravou
    if(sibling->left!=NULL && !strcmp(node->left->value,sibling->right->value) && sibling->right!=node->left){
        sibling->right = node->left;
        sibling->reduced++;
        bdd->nodeCount--;
    }

    //ak sa pravé strany rovnajú
    if(sibling->left!=NULL && !strcmp(node->right->value,sibling->right->value) && sibling->right != node->right){
        sibling->right = node->right;
        sibling->reduced++;
        bdd->nodeCount--;
    }

    //ak sa rovná pravá strana s ľavou
    if(sibling->left!=NULL && !strcmp(node->right->value,sibling->left->value) && sibling->left != node->right){
        sibling->left = node->right;
        sibling->reduced++;
        bdd->nodeCount--;
    }
}


void findSibling(struct Node *node, struct Node *sibling, BDD *bdd){

    //Funkcia prebieha, kým nenájde uzol, ktoréh ohodnota má rovnakú dĺžku
    if(strlen(sibling->value)==strlen(node->value)){
        //skontroluje sa, či sú niektorí z potomkov rovnakí
        checkSibling(node,sibling,bdd);
        return;
    }

    //rekurzívne volanie s potomkami
    findSibling(node,sibling->left,bdd);
    findSibling(node,sibling->right,bdd);
}

//REDUKCIA NA PREPOJENIE ROVNAKÝCH UZLOV
void reduce_redundant(struct Node *node, BDD *bdd){

    //AK uzol list, funkcia sa ukončí
    if(strlen(node->value)==1){
        return;
    }

    //AK ešte nebol uzol zredukovaný, skontroluje sa, či je redukcia potrebná
    if(node->reduced==0){
        if(node->parent!=NULL) {
            findSibling(node, bdd->root, bdd);   //kontrola všetkých uzlov v úrovni
        }

            //Prípad, ak má root rovnakých potomkov
        else{
            if(!strcmp(node->left->value,node->right->value)){
                node->right = node->left;

                //Odpočítavajú sa vštky uzly vychádzajúce z vymazaného potomka
                bdd->nodeCount-=(strlen(node->left->value)-1);
            }
        }
    }

    reduce_redundant(node->left,bdd);
    reduce_redundant(node->right,bdd);
}

//FUNKCIA NA REDUKOVANIE UZLOV, KTORÝCH POTOMKOVIA MAJÚ ROVNAKÚ HODNOTU
void reduce_siblings(struct Node *node, BDD *bdd){

    //Reukrzia sa ukončí, ak je uzol null, alebo list
    if(node==NULL || node->left == NULL){
        return;
    }

    struct Node *left = node->left->left, *right = node->right->right;
    if(node->left == node->right) {
        if(node->parent!=NULL){
            struct Node *parent = node->parent;

            //AK je to aktuálny uzol ľavý potomok
            if(parent->left==node){
                node->left->parent=parent;              //nový rodič
                parent->left=node->left;                //potomok rodiča, bude potomok aktuálneho uzla
                bdd->nodeCount-=2;
            }
            else{
                node->left->parent=parent;              //nový rodič
                parent->right=node->left;               //potomok rodiča, bude potomok aktuálneho uzla
                bdd->nodeCount-=2;
            }
        }


            //V prípade, že parent je Null, je potrebné spraviť redukciu v roote
        else{
            //Nastavenie nových potomkov pre root
            node->left=left;
            node->right=right;

            //Nastavenie rodiča-root pre nových potomkov
            left->parent=node;
            right->parent=node;
            bdd->nodeCount-=2;
        }
    }

    //rekurzívne volanie pre potomkov
    reduce_siblings(node->left,bdd);
    reduce_siblings(node->right,bdd);
}

int BDD_reduce(BDD *bdd){
    reduce_redundant(bdd->root, bdd);     //prepojenie rovnakých uzlov v tej istej  úrovni stormu
    reduce_siblings(bdd->root, bdd);     //redukovanie uzlov, ktoré majú rovnakých potomkov
    return 1;
}

char BDD_use(BDD *bdd, char *vstupy) {
    struct Node *node = bdd->root;
    int lenght = strlen(vstupy);

    //Cyklus prebieha, kým funkcia nepríde do listu
    for (int i = 0; i < strlen(vstupy); i++) {

        //Ak sa dĺžka hodnoty uzla nerovná dĺžke, ktorá je teraz, uzol bol vymazaný
        //a nie je potrebné žiadne rozhodnutie
        if (strlen(node) == lenght) {

            //Ak je to 0, posunie sa v strome doľava, ak 1 tak doprava
            if (vstupy[i] == '0') {
                node = node->left;
            } else if (vstupy[i] == '1') {
                node = node->right;
            }

        }
        lenght = lenght / 2; //nastavenie novej dĺžky pre úroveň stromu
    }

    //Vrátenie hodnoty v liste
    if (strlen(node->value) == 1) {
        return node->value[0];
    }
    return -1;
}

const char alphabet[] = "10";
int intN(int n) {
    return rand() % n;
}


//POMOCNÁ FUNKCIA PRE GENEROVANIE VEKTORA
char *randomString(int len) {
    char *s = malloc((len + 1) * sizeof(char));
    for (int i = 0; i < len; i++) {
        s[i] = alphabet[intN(strlen(alphabet))];
    }
    s[len] = '\0';
    return s;
}


//POMOCNÁ FUNKCIA NA VYTOVRENIE KOMBINÁCIE PREMIEN
char **createVariables(int var, int size){
    char **variables;

    variables = (char**) malloc(size*sizeof (char*));
    for(int i =0; i<size; i++){
        variables[i]= (char*) malloc(var *sizeof(char));
        variables[i] = randomString(var);
    }
    return variables;
}



#endif //UNTITLED6_PROGRAM_H
